var menu = $("#menu");
var barrabusqueda = $(".barrabusqueda");
var barra  = $("#buscar");
var icono = $(".icon-search");

barrabusqueda.focusin(function(){
	barrabusqueda.css("width","20%");
	menu.css("width","80%");
	icono.css("color","black");
	barra.css("color","black");
});

barrabusqueda.focusout(function(){
	barrabusqueda.css("width","15%");
	menu.css("width","85%");
	icono.css("color","white");
	barra.css("color","white");
});