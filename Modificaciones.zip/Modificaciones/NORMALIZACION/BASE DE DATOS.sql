﻿/*==============================================================*/
/* DBMS name:      PostgreSQL 8                                 */
/* Created on:     05/06/2016 02:47:17 p.m.                     */
/*==============================================================*/


/*drop index ADMINISTRADORES_PK;

drop table ADMINISTRADORES;

drop index CATEGORIAS_PK;

drop table CATEGORIAS;

drop index CLIENTES_PK;

drop table CLIENTES;

drop index FK_CLIENTES_ORDENES_FK;

drop index ORDENES_PK;

drop table ORDENES;

drop index FK_PRODUCTOS_ORDENESDETALLES_FK;

drop index FK_ORDENES_ORDENESDETALLES_FK;

drop index ORDENESDETALLES_PK;

drop table ORDENESDETALLES;

drop index FK_PROVEEDORES_PEDIDOS_FK;

drop index FK_ADMINISTRADORES_PEDIDOS_FK;

drop index PEDIDOS_PK;

drop table PEDIDOS;

drop index FK_PRODUCTOS_PEDIDOSDETALLES_FK;

drop index FK_PEDIDOS_PEDIDOSDETALLE_FK;

drop index PEDIDOSDETALLES_PK;

drop table PEDIDOSDETALLES;

drop index FK_PROVEEDORES_PRODUCTOS_FK;

drop index FK_CATEGORIAS_PRODUCTOS_FK;

drop index PRODUCTOS_PK;

drop table PRODUCTOS;

drop index PROVEEDORES_PK;

drop table PROVEEDORES;*/

/*==============================================================*/
/* Table: ADMINISTRADORES                                       */
/*==============================================================*/
create table ADMINISTRADORES (
   IDADMINISTRADOR      SERIAL               not null,
   NOMBRE               VARCHAR(50)          not null,
   IDENTIFICADOR        VARCHAR(20)          not null,
   CLAVE                VARCHAR(20)          null,
   constraint PK_ADMINISTRADORES primary key (IDADMINISTRADOR)
);

/*==============================================================*/
/* Index: ADMINISTRADORES_PK                                    */
/*==============================================================*/
create unique index ADMINISTRADORES_PK on ADMINISTRADORES (
IDADMINISTRADOR
);

/*==============================================================*/
/* Table: CATEGORIAS                                            */
/*==============================================================*/
create table CATEGORIAS (
   IDCATEGORIA          SERIAL               not null,
   NOMBRE               VARCHAR(50)          not null,
   constraint PK_CATEGORIAS primary key (IDCATEGORIA)
);

/*==============================================================*/
/* Index: CATEGORIAS_PK                                         */
/*==============================================================*/
create unique index CATEGORIAS_PK on CATEGORIAS (
IDCATEGORIA
);

/*==============================================================*/
/* Table: CLIENTES                                              */
/*==============================================================*/
create table CLIENTES (
   IDCLIENTE            SERIAL               not null,
   NOMBRES              VARCHAR(100)         not null,
   IDENTIFICADOR        VARCHAR(20)          not null,
   CLAVE                VARCHAR(20)          not null,
   CORREO               VARCHAR(50)          not null,
   FECHANACIMIENTO      DATE                 not null,
   constraint PK_CLIENTES primary key (IDCLIENTE)
);

/*==============================================================*/
/* Index: CLIENTES_PK                                           */
/*==============================================================*/
create unique index CLIENTES_PK on CLIENTES (
IDCLIENTE
);

/*==============================================================*/
/* Table: ORDENES                                               */
/*==============================================================*/
create table ORDENES (
   IDORDEN              SERIAL               not null,
   IDCLIENTE            INT4                 not null,
   FECHA                DATE                 not null,
   PAGADA               BOOL                 not null,
   TOTAL                DECIMAL(10,2)        not null,
   constraint PK_ORDENES primary key (IDORDEN)
);

/*==============================================================*/
/* Index: ORDENES_PK                                            */
/*==============================================================*/
create unique index ORDENES_PK on ORDENES (
IDORDEN
);

/*==============================================================*/
/* Index: FK_CLIENTES_ORDENES_FK                                */
/*==============================================================*/
create  index FK_CLIENTES_ORDENES_FK on ORDENES (
IDCLIENTE
);

/*==============================================================*/
/* Table: ORDENESDETALLES                                       */
/*==============================================================*/
create table ORDENESDETALLES (
   IDORDEN              INT4                 not null,
   IDPRODUCTO           INT4                 not null,
   CANTIDAD             INT4                 not null,
   PRECIOUNITARIO       DECIMAL(10,2)        not null,
   TOTAL                DECIMAL(10,2)        null,
   constraint PK_ORDENESDETALLES primary key (IDORDEN, IDPRODUCTO)
);

/*==============================================================*/
/* Index: ORDENESDETALLES_PK                                    */
/*==============================================================*/
create unique index ORDENESDETALLES_PK on ORDENESDETALLES (
IDORDEN,
IDPRODUCTO
);

/*==============================================================*/
/* Index: FK_ORDENES_ORDENESDETALLES_FK                         */
/*==============================================================*/
create  index FK_ORDENES_ORDENESDETALLES_FK on ORDENESDETALLES (
IDORDEN
);

/*==============================================================*/
/* Index: FK_PRODUCTOS_ORDENESDETALLES_FK                       */
/*==============================================================*/
create  index FK_PRODUCTOS_ORDENESDETALLES_FK on ORDENESDETALLES (
IDPRODUCTO
);

/*==============================================================*/
/* Table: PEDIDOS                                               */
/*==============================================================*/
create table PEDIDOS (
   IDPEDIDO             SERIAL               not null,
   IDADMINISTRADOR      INT4                 null,
   IDPROVEEDOR          INT4                 null,
   FECHAPEDIDO          DATE                 not null,
   constraint PK_PEDIDOS primary key (IDPEDIDO)
);

/*==============================================================*/
/* Index: PEDIDOS_PK                                            */
/*==============================================================*/
create unique index PEDIDOS_PK on PEDIDOS (
IDPEDIDO
);

/*==============================================================*/
/* Index: FK_ADMINISTRADORES_PEDIDOS_FK                         */
/*==============================================================*/
create  index FK_ADMINISTRADORES_PEDIDOS_FK on PEDIDOS (
IDADMINISTRADOR
);

/*==============================================================*/
/* Index: FK_PROVEEDORES_PEDIDOS_FK                             */
/*==============================================================*/
create  index FK_PROVEEDORES_PEDIDOS_FK on PEDIDOS (
IDPROVEEDOR
);

/*==============================================================*/
/* Table: PEDIDOSDETALLES                                       */
/*==============================================================*/
create table PEDIDOSDETALLES (
   IDPEDIDO             INT4                 not null,
   IDPRODUCTO           INT4                 not null,
   CANTIDAD             INT4                 not null,
   TOTAL                DECIMAL(10,2)        not null,
   constraint PK_PEDIDOSDETALLES primary key (IDPEDIDO, IDPRODUCTO)
);

/*==============================================================*/
/* Index: PEDIDOSDETALLES_PK                                    */
/*==============================================================*/
create unique index PEDIDOSDETALLES_PK on PEDIDOSDETALLES (
IDPEDIDO,
IDPRODUCTO
);

/*==============================================================*/
/* Index: FK_PEDIDOS_PEDIDOSDETALLE_FK                          */
/*==============================================================*/
create  index FK_PEDIDOS_PEDIDOSDETALLE_FK on PEDIDOSDETALLES (
IDPEDIDO
);

/*==============================================================*/
/* Index: FK_PRODUCTOS_PEDIDOSDETALLES_FK                       */
/*==============================================================*/
create  index FK_PRODUCTOS_PEDIDOSDETALLES_FK on PEDIDOSDETALLES (
IDPRODUCTO
);

/*==============================================================*/
/* Table: PRODUCTOS                                             */
/*==============================================================*/
create table PRODUCTOS (
   IDPRODUCTO           SERIAL               not null,
   IDCATEGORIA          INT4                 not null,
   IDPROVEEDOR          INT4                 not null,
   NOMBRE               VARCHAR(30)          not null,
   DESCRIPCION          VARCHAR(100)         not null,
   PRECIOUNITARIO       DECIMAL(10,2)        not null,
   PRECIOPROVEEDOR      DECIMAL(10,2)        not null,
   PRECIOPROMOCION      DECIMAL(10,2)        not null,
   constraint PK_PRODUCTOS primary key (IDPRODUCTO)
);

/*==============================================================*/
/* Index: PRODUCTOS_PK                                          */
/*==============================================================*/
create unique index PRODUCTOS_PK on PRODUCTOS (
IDPRODUCTO
);

/*==============================================================*/
/* Index: FK_CATEGORIAS_PRODUCTOS_FK                            */
/*==============================================================*/
create  index FK_CATEGORIAS_PRODUCTOS_FK on PRODUCTOS (
IDCATEGORIA
);

/*==============================================================*/
/* Index: FK_PROVEEDORES_PRODUCTOS_FK                           */
/*==============================================================*/
create  index FK_PROVEEDORES_PRODUCTOS_FK on PRODUCTOS (
IDPROVEEDOR
);

/*==============================================================*/
/* Table: PROVEEDORES                                           */
/*==============================================================*/
create table PROVEEDORES (
   IDPROVEEDOR          SERIAL               not null,
   NOMBREPROVEEDOR      VARCHAR(50)          not null,
   constraint PK_PROVEEDORES primary key (IDPROVEEDOR)
);

/*==============================================================*/
/* Index: PROVEEDORES_PK                                        */
/*==============================================================*/
create unique index PROVEEDORES_PK on PROVEEDORES (
IDPROVEEDOR
);

alter table ORDENES
   add constraint FK_ORDENES_FK_CLIENT_CLIENTES foreign key (IDCLIENTE)
      references CLIENTES (IDCLIENTE)
      on delete restrict on update restrict;

alter table ORDENESDETALLES
   add constraint FK_ORDENESD_FK_ORDENE_ORDENES foreign key (IDORDEN)
      references ORDENES (IDORDEN)
      on delete restrict on update restrict;

alter table ORDENESDETALLES
   add constraint FK_ORDENESD_FK_PRODUC_PRODUCTO foreign key (IDPRODUCTO)
      references PRODUCTOS (IDPRODUCTO)
      on delete restrict on update restrict;

alter table PEDIDOS
   add constraint FK_PEDIDOS_FK_ADMINI_ADMINIST foreign key (IDADMINISTRADOR)
      references ADMINISTRADORES (IDADMINISTRADOR)
      on delete restrict on update restrict;

alter table PEDIDOS
   add constraint FK_PEDIDOS_FK_PROVEE_PROVEEDO foreign key (IDPROVEEDOR)
      references PROVEEDORES (IDPROVEEDOR)
      on delete restrict on update restrict;

alter table PEDIDOSDETALLES
   add constraint FK_PEDIDOSD_FK_PEDIDO_PEDIDOS foreign key (IDPEDIDO)
      references PEDIDOS (IDPEDIDO)
      on delete restrict on update restrict;

alter table PEDIDOSDETALLES
   add constraint FK_PEDIDOSD_FK_PRODUC_PRODUCTO foreign key (IDPRODUCTO)
      references PRODUCTOS (IDPRODUCTO)
      on delete restrict on update restrict;

alter table PRODUCTOS
   add constraint FK_PRODUCTO_FK_CATEGO_CATEGORI foreign key (IDCATEGORIA)
      references CATEGORIAS (IDCATEGORIA)
      on delete restrict on update restrict;

alter table PRODUCTOS
   add constraint FK_PRODUCTO_FK_PROVEE_PROVEEDO foreign key (IDPROVEEDOR)
      references PROVEEDORES (IDPROVEEDOR)
      on delete restrict on update restrict;

