package clases;

public class Pedido {
    private int idPedido;
    private int cantidad;
    private double total;

    public Pedido() {
    }

    public Pedido(int idPedido, int cantidad, double total) {
        this.idPedido = idPedido;
        this.cantidad = cantidad;
        this.total = total;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "Pedido \n" + "Codigo: " + idPedido + "\n Cantidad:  " + cantidad + "\n Total: " + total;
    }
}
